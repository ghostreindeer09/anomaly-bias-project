import pandas as pd
from sklearn.cluster import KMeans
import plotly.express as px

def load_data(uploaded_file):
    return pd.read_csv(uploaded_file)

def detect_anomalies(df, features, n_clusters=2):
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    df['cluster'] = kmeans.fit_predict(df[features])
    
    counts = df['cluster'].value_counts()
    anomaly_label = counts.idxmin()  # cluster with least points = anomaly
    
    df['anomaly'] = df['cluster'] == anomaly_label
    return df, anomaly_label, counts

def visualize_clusters(df, x, y):
    fig = px.scatter(
        df, x=x, y=y, color='anomaly',
        color_discrete_map={True: 'red', False: 'blue'},
        title="Anomaly Detection via Clustering",
        hover_data=df.columns  # show all row info on hover
    )
    return fig

def visualize_survivorship_bias(df, condition_col):
    survived = df[df[condition_col] == 1]
    failed = df[df[condition_col] == 0]

    # Add status column to differentiate in the combined dataframe
    survived = survived.assign(status='Survived')
    failed = failed.assign(status='Failed')

    combined = pd.concat([survived, failed])

    fig = px.histogram(
        combined,
        x='score',
        color='status',
        nbins=20,
        opacity=0.7,
        barmode='overlay',
        color_discrete_map={'Survived': 'green', 'Failed': 'red'},
        title="Survivorship Bias Visualization"
    )
    fig.update_layout(bargap=0.2)
    return fig
