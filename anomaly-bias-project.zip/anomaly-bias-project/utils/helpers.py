import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import seaborn as sns
import os

def load_data(filepath):
    return pd.read_csv(filepath)

def detect_anomalies(df, features, n_clusters=2):
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    df['cluster'] = kmeans.fit_predict(df[features])
    
    # Assume minority cluster is anomaly
    counts = df['cluster'].value_counts()
    anomaly_label = counts.idxmin()
    df['anomaly'] = df['cluster'] == anomaly_label
    return df

def visualize_clusters(df, x, y, save_path):
    plt.figure(figsize=(8, 6))
    sns.scatterplot(data=df, x=x, y=y, hue='anomaly', palette={True: 'red', False: 'blue'})
    plt.title("Anomaly Detection via Clustering")
    plt.savefig(save_path)
    plt.close()

def visualize_survivorship_bias(df, condition_col, save_path):
    survived = df[df[condition_col] == 1]
    failed = df[df[condition_col] == 0]

    plt.figure(figsize=(8, 6))
    sns.kdeplot(survived['score'], label='Survived', fill=True)
    sns.kdeplot(failed['score'], label='Failed', fill=True)
    plt.title("Survivorship Bias Visualization")
    plt.legend()
    plt.savefig(save_path)
    plt.close()

if __name__ == "__main__":
    # Load your CSV file here
    filepath = "your_data.csv"  # Replace with your actual file path
    df = load_data(filepath)
    
    # Print columns to choose features from
    print("Columns in data:", df.columns.tolist())
    
    # Define features for clustering (replace with your actual column names)
    features = ['feature1', 'feature2']  # Example: ['age', 'income']
    
    # Detect anomalies
    df = detect_anomalies(df, features)
    
    # Paths to save the plots
    CLUSTER_PLOT_PATH = "cluster_plot.png"
    SURVIVORSHIP_PLOT_PATH = "survivorship_plot.png"
    
    # Visualize clusters
    visualize_clusters(df, features[0], features[1], CLUSTER_PLOT_PATH)
    
    # For survivorship bias visualization, replace 'condition_col' with your actual column
    # visualize_survivorship_bias(df, condition_col='your_condition_column', save_path=SURVIVORSHIP_PLOT_PATH)
