import streamlit as st
import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import seaborn as sns

def detect_anomalies(df, features, n_clusters=2):
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    df['cluster'] = kmeans.fit_predict(df[features])
    counts = df['cluster'].value_counts()
    anomaly_label = counts.idxmin()
    df['anomaly'] = df['cluster'] == anomaly_label
    return df

def visualize_clusters(df, x, y):
    plt.figure(figsize=(8, 6))
    sns.scatterplot(data=df, x=x, y=y, hue='anomaly', palette={True: 'red', False: 'blue'})
    plt.title("Anomaly Detection via Clustering")
    st.pyplot(plt)
    plt.close()

def visualize_survivorship_bias(df, condition_col):
    survived = df[df[condition_col] == 1]
    failed = df[df[condition_col] == 0]

    plt.figure(figsize=(8, 6))
    sns.kdeplot(survived['score'], label='Survived', fill=True)
    sns.kdeplot(failed['score'], label='Failed', fill=True)
    plt.title("Survivorship Bias Visualization")
    plt.legend()
    st.pyplot(plt)
    plt.close()

st.title("Anomaly & Survivorship Bias Visualization")

uploaded_file = st.file_uploader("Upload your CSV file", type=["csv"])

if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)
    st.write("Data Preview:")
    st.dataframe(df.head())

    st.header("Anomaly Detection")

    features = st.multiselect("Select features for clustering (at least 2)", options=df.columns.tolist())
    if len(features) >= 2:
        n_clusters = st.slider("Select number of clusters", min_value=2, max_value=10, value=2, step=1)
        df = detect_anomalies(df, features, n_clusters=n_clusters)
        st.write(f"Showing anomaly clusters for features: {features[0]} and {features[1]}")
        visualize_clusters(df, features[0], features[1])
    else:
        st.info("Select at least two features for clustering.")

    st.header("Survivorship Bias")

    condition_cols = df.columns[df.nunique() == 2].tolist()  # binary cols
    if condition_cols:
        condition_col = st.selectbox("Select condition column (binary)", options=condition_cols)
        if 'score' in df.columns:
            visualize_survivorship_bias(df, condition_col)
        else:
            st.warning("No 'score' column found for survivorship bias plot.")
    else:
        st.info("No binary column found for survivorship bias visualization.")
else:
    st.info("Upload a CSV file to get started.")
